# Montaža — instalacija na cPanel (montaza.aggroup.rs)

Ukupno 10–15 minuta. Ne treba ništa da se programira, ni da se dira phpMyAdmin.

---

## 1. Subdomen i HTTPS (cPanel)

1. **Domains** (ili **Subdomains**) → napravi `montaza.aggroup.rs`. Zapamti njegov folder (**Document Root**), npr. `/home/KORISNIK/montaza.aggroup.rs`.
2. **SSL/TLS Status** → označi `montaza.aggroup.rs` → **Run AutoSSL**.
   HTTPS je obavezan: bez njega kamera na telefonu i „Dodaj na početni ekran" ne rade.

## 2. Prazna baza (cPanel → MySQL Databases)

1. **Create New Database** → npr. `montaza`. cPanel doda prefiks, pa se zove npr. `KORISNIK_montaza`.
2. **Add New User** → npr. `mz` (biće `KORISNIK_mz`) → lozinka preko **Password Generator**. **Zapiši je.**
3. **Add User To Database** → izaberi tog korisnika i bazu → **ALL PRIVILEGES** → Make Changes.

## 3. ZIP (cPanel → File Manager)

1. Otvori folder subdomena iz koraka 1.
2. **Upload** → `montaza-YYYYMMDD.zip`.
3. Desni klik na ZIP → **Extract** → u isti folder.
4. Obriši ZIP.

## 4. Instalacija (u browseru)

Otvori **https://montaza.aggroup.rs**. Sam te prebaci na instalaciju:

1. **Korak 1 — baza:** upiši ime baze, korisnika i lozinku iz koraka 2 → **Poveži i napravi tabele**.
   Ako nešto ne valja, piše tačno šta (pogrešna lozinka, baza ne postoji…).
2. **Korak 2 — nalozi:** imena su već upisana (Aleksandar, Oliver, Steva). Svako upiše **svoju lozinku** od 4 cifre → **Napravi naloge**.
3. Na kraju instalacija:
   - sama obriše `install.php`;
   - ispiše dve komande za dnevne poslove (korak 7). Kopiraj ih.

Uradi korak 4 odmah posle raspakivanja: dok instalacija nije završena, `install.php` može da otvori bilo ko.

## 5. Telefoni i obaveštenja

Svako na svom telefonu:
1. Otvori **https://montaza.aggroup.rs** i prijavi se. „Zapamti me" drži prijavu 30 dana.
2. **Instaliraj kao aplikaciju:**
   - **Android (Chrome):** u Montaži se pojavi kartica **„Instaliraj Montažu kao aplikaciju"** → **Instaliraj**. Ako je nema: meni ⋮ → **Instaliraj aplikaciju**. Ne koristi „Dodaj na početni ekran", to pravi samo prečicu. Montaža se zatim pojavi u spisku aplikacija i otvara se bez adresne trake. Dugi pritisak na ikonicu nudi prečice Danas, Zadaci i Novi zadatak.
   - **iPhone (Safari):** dugme Deli (□↑) → **Add to Home Screen**.
3. **Otvori Montažu sa ikonice** → u kartici „Obaveštenja na ovom telefonu" dodirni **Uključi** (ili zvonce gore) → **Dozvoli**.
   Odmah stiže probno obaveštenje „Obaveštenja su uključena ✓", a zvonce postane zeleno.

Obaveštenja stižu kao kod svake aplikacije, i kad je Montaža zatvorena. Dodir na obaveštenje otvara taj projekat ili zadatak.
- **iPhone:** potreban je iOS 16.4 ili noviji, a Montaža mora biti otvorena sa ikonice na početnom ekranu, ne iz Safarija.
- **Android:** radi u Chrome-u. Ako je slučajno kliknuto „Blokiraj": katanac pored adrese → Obaveštenja → Dozvoli.
- U **Podešavanja → Korisnici** vidiš ko ima uključena obaveštenja i na koliko telefona.

Zaštita kratkih lozinki:
- posle 5 pogrešnih pokušaja nalog je zaključan 15 minuta;
- posle 20 pogrešnih pokušaja u toku dana zaključan je 24 sata, a Aleksandar dobija poruku;
- Aleksandar može ranije da otključa nalog: **Podešavanja → korisnik → Otključaj nalog**.

## 6. Telegram (opciono)

Obaveštenja iz koraka 5 su dovoljna. Telegram je dodatni kanal, ako ga želite: na telefonu treba samo aplikacija **Telegram**.

1. Aleksandar: u Telegramu otvori **@BotFather** → `/newbot` → ime npr. „AG Montaža" → dobiješ **token** (`123456789:ABC…`).
   Napravi **novi** bot samo za Montažu. Bot za upite koji već koristiš verovatno ne može da se deli.
2. U aplikaciji Montaža: **Podešavanja → Telegram** → nalepi token → **Sačuvaj podešavanja**.
3. Aleksandar, Oliver i Steva u Telegramu pronađu bota (po imenu iz koraka 1) i pritisnu **Start**, odnosno pošalju bilo koju poruku.
4. **Podešavanja → Pronađi chat ID** → pojave se imena i brojevi. Upiši broj svakom korisniku (otvori korisnika → *Telegram chat ID* → Sačuvaj) → **Pošalji test poruku**.

Ko šta dobija, isto i na telefon i na Telegram:
- **Oliver i Steva:** novi projekat i raspoređivanje („montaža pon 10.11. – pet 14.11.").
- **Steva:** „Spremno za montažu" kad Oliver zatvori pakovanje.
- **Aleksandar:**
  - gotove stavke u hali;
  - naplata, i odmah razlika u iznosu ako je ima;
  - zastoji;
  - završena montaža.
- **Za zadatke:** kome je zadatak dat dobija poruku kad ga dobije, a ko ga je zadao kad je završen ili kad ima zastoj.

## 7. Dnevna obaveštenja i rezervna kopija (cPanel → Cron Jobs)

Dodaj **dva** posla (**Add New Cron Job**). Zameni `KORISNIK` svojim cPanel nalogom:

| Kada | Minute | Hour | Day | Month | Weekday | Command |
|---|---|---|---|---|---|---|
| jutro | `5` | `7` | `*` | `*` | `*` | `/usr/local/bin/php /home/KORISNIK/montaza.aggroup.rs/montaza-app/cron/dnevni.php` |
| veče | `5` | `18` | `*` | `*` | `*` | `/usr/local/bin/php /home/KORISNIK/montaza.aggroup.rs/montaza-app/cron/dnevni.php --vece` |

**Ujutru** posao radi sledeće:
- ekipi šalje današnje termine;
- svakome šalje zadatke i faze kojima je danas rok ili kasne;
- vlasniku šalje projekte kojima rok ističe danas ili za 3 dana;
- **ponedeljkom** vlasniku šalje pregled nedelje: termine, šta traži odluku, zastoje, kašnjenja, naplatu i gotovinu kod radnika;
- briše slike koje su poslate, a nikad sačuvane;
- pravi **rezervnu kopiju baze** u `montaza-app/backups/`. Čuva poslednjih 14.

**Uveče** posao radi sledeće:
- ekipi šalje sutrašnje termine;
- hali i vlasniku šalje sutrašnje montaže kojima proizvod još nije gotov.

Proba bez slanja: `php dnevni.php --dry-run`.

**Vraćanje kopije:** preuzmi `.sql.gz` iz File Managera (`montaza-app/backups/`), pa ga uvezi preko phpMyAdmin → Import.

---

## Jednostavna verzija (v3) — ažuriranje postojeće aplikacije

Aplikacija ima tri ekrana: **Projekti**, **Montaže** i **Izveštaj**. Svi projekti, slike, komentari i nalozi ostaju.

1. *(preporuka)* phpMyAdmin → baza → **Export** → **Go**.
2. File Manager → folder subdomena → **Otpremi** `montaza-azuriranje-*.zip` → **Izdvoji** u isti folder → zameni postojeće → obriši ZIP.
3. Otvori sajt. Baza se sama dopuni:
   - svaki projekat dobije stavke kao u prvoj verziji (nalog, čelik, aluminijum, cerada, pakovanje, montaža) sa stanjem koje je već urađeno;
   - datum montaže se prepiše iz termina.
4. **Cron:** zameni stare poslove sa ova dva (komanda je ista, samo je posao drugačiji):
   - `5 7 * * *` → `/usr/local/bin/php /home/KORISNIK/montaza.aggroup.rs/montaza-app/cron/dnevni.php`
   - `5 18 * * *` → ista komanda + ` --vece`
5. Na telefonima: zatvori Montažu i otvori je ponovo.

Zadaci, naplata, ekipe i sistemi više se ne prikazuju. Njihovi podaci ostaju u bazi.

## Prelazak na verziju 2 (aplikacija je već instalirana i radi)

Podaci ostaju sačuvani: projekti, slike, zadaci, uplate i nalozi. **Ne** uvoziš SQL i **ne** pokrećeš instalaciju.

1. **Kopija pre izmene:** phpMyAdmin → baza `aggroup_montaza` → **Export** → **Go**. Sačuvaj fajl.
2. File Manager → folder subdomena → **Otpremi** `montaza-azuriranje-*.zip` → desni klik → **Izdvoji** u isti folder. Kad pita, **zameni** postojeće fajlove. Zatim obriši ZIP.
   `config.php`, `uploads/` i baza ostaju netaknuti.
3. Otvori **https://montaza.aggroup.rs**. Prvo otvaranje sámo nadogradi bazu, za nekoliko sekundi:
   - svaki projekat dobije svoj sistem;
   - stavke postanu faze proizvodnje;
   - montaže postanu termini;
   - naplate postanu uplate.
   Ako u tom trenutku još neko otvori aplikaciju, vidi poruku „Aplikacija se ažurira — pokušaj ponovo za minut".
4. **Podešavanja** (zupčanik):
   - **Ekipe:** proveri „Steva + ekipa". Dodaj ostale ekipe ako ih imaš.
   - **Sistemi i faze:** proveri spisak faza za svaki tip (BIOFIX, ZIP screen…). Promena važi za nove projekte.
5. **Cron:** ako si imao ponedeljni pregled, obriši ga i dodaj dva nova posla iz koraka 7.
6. Na telefonima: zatvori Montažu i otvori je ponovo. Tako se učitava nova verzija.

**Proveri posle prelaska:**
- **Danas** prikazuje kartice „Traži odluku / U zastoju / Kasni / Za naplatu";
- otvori jedan stari projekat → tab **Proizvodnja**: tamo su faze;
- otvori tab **Montaža**: tamo su termini.

Ako nešto ne valja, vrati staro:
1. Otpremi i izdvoji prethodni ZIP.
2. U phpMyAdmin-u obriši sve tabele.
3. Uvezi kopiju iz koraka 1.

## Pregaziti staru aplikaciju na istom subdomenu i u istoj bazi

1. *(preporuka)* phpMyAdmin → stara baza → **Export** → **Go**, za svaki slučaj.
2. Zapiši korisnika i lozinku baze. Stara aplikacija ih obično drži u `.env` (`DB_USERNAME`, `DB_PASSWORD`). Ako ih nemaš: MySQL Databases → novi korisnik → *Add User To Database* → ALL PRIVILEGES.
3. File Manager → folder subdomena → *Settings → Show Hidden Files* → **Izaberi sve** → skini štiklu sa `.well-known` → **Obriši**.
4. **Otpremi** ZIP → **Izdvoji** → obriši ZIP.
5. **Domeni** → subdomen → **Upravljaj** → *Koren dokumenta* neka bude sam folder subdomena (npr. `montaza.aggroup.rs`, bez `/…/public`).
6. phpMyAdmin → levo **klikni bazu** → **Import** → `montaza-baza.sql` → **Go**. Ovo briše sve stare tabele u **toj** bazi i pravi nove.
7. Otvori sajt → instalacija (korak 4 gore).

## Česti problemi

| Problem | Rešenje |
|---|---|
| Instalacija: „Pogrešan korisnik ili lozinka" | Korak 2.3 — korisnik mora biti dodat na bazu sa ALL PRIVILEGES. |
| Instalacija: „Baza ne postoji" | Upiši puno ime sa prefiksom, npr. `KORISNIK_montaza`. |
| Instalacija: „server ne dozvoljava upis fajla" | Uradi ono što piše na ekranu: napravi `montaza-app/config.php` sa prikazanim tekstom. |
| „Došlo je do greške" | Pogledaj `montaza-app/logs/app.log` u File Manager-u. |
| Slika ili PDF „prevelik" | cPanel → **MultiPHP INI Editor**: `upload_max_filesize` ≥ 20M, `post_max_size` ≥ 64M. |
| Obaveštenja ne stižu | Proveri da je zvonce zeleno. Na iPhone-u otvori Montažu sa ikonice, ne iz Safarija. U podešavanjima telefona obaveštenja za Montažu/Chrome moraju biti uključena. |
| Kamera se ne otvara | Sajt mora biti na **https://** (korak 1, AutoSSL). |
| Zaboravljena lozinka | Aleksandar: **Podešavanja → korisnik → Nova lozinka**. |
| Aleksandar zaboravio svoju lozinku | cPanel **Terminal**: `php -r 'echo password_hash("NOVA", PASSWORD_DEFAULT);'` → phpMyAdmin → tabela `users` → red `aleksandar` → nalepi u `password_hash`. |
| Ponovna instalacija od nule | Obriši `montaza-app/config.php` i sve tabele u bazi, pa ponovo otpakuj ZIP. |

**Ažuriranje (nova verzija):** File Manager → folder subdomena → **Otpremi** `montaza-azuriranje-*.zip` → **Izdvoji** (zameni postojeće) → obriši ZIP. Podešavanja, baza i slike ostaju netaknuti.

**Rezervna kopija:** cPanel → **Backup** → preuzmi bazu (MySQL) i folder `uploads/`, makar jednom mesečno.
